# AWS Load Balancer Controller

AWS Load Balancer controller Helm chart for Kubernetes


Dependency on [aws-load-balancer-controller-v2.2.1](https://github.com/kubernetes-sigs/aws-load-balancer-controller/tree/v2.2.1)



## Configuration

The following tables lists the configurable parameters of the chart and their default values.
The default values set by the application itself can be confirmed [here](https://kubernetes-sigs.github.io/aws-load-balancer-controller/guide/controller/configurations/).

| Parameter                                   | Description                                                                                              | Default                                                                            |
| ------------------------------------------- | -------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------- |
| `clusterName`                               | Kubernetes cluster name                                                                                  | cluster-name                                                                               |
| `resources`                                 | Controller pod resource requests & limits                                                                | `requests:cpu: 100m;memory: 128Mi`                                                                               |
| `serviceAccount.annotations`                | optional annotations to add to service account                                                           | None                                                                               |
| `serviceAccount.create`                     | If `true`, create a new service account                                                                  | `false`                                                                             |
| `serviceAccount.name`                       | Service account to be used                                                                               |       aws-load-balancer-controller                                                                       |
| `ingressClass`                              | The ingress class to satisfy                                                                             | alb                                                                                |
| `region`                                    | The AWS region for the kubernetes cluster                                                                | ap-south-1                                                                               |
| `vpcId`                                     | The VPC ID for the Kubernetes cluster                                                                    | vpc-xxxx                                                                               |
