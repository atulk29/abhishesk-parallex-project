# vertical-pod-autoscaler

![Version: 2.0.0](https://img.shields.io/badge/Version-2.0.0-informational?style=flat-square)  ![AppVersion: 0.1.0](https://img.shields.io/badge/AppVersion-0.1.0-informational?style=flat-square)

## Description

Set of components that automatically adjust the amount of CPU and memory requested by pods running in the Kubernetes Cluster

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| siddharth | <abhibvp003@gmail.com> |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| admissionController.cleanupOnDelete.enabled | bool | `true` |  |
| admissionController.cleanupOnDelete.image.repository | string | `"quay.io/reactiveops/ci-images"` |  |
| admissionController.cleanupOnDelete.image.tag | string | `"v11-alpine"` |  |
| admissionController.enabled | bool | `true` |  |
| admissionController.image.pullPolicy | string | `"Always"` |  |
| admissionController.image.repository | string | `"k8s.gcr.io/autoscaling/vpa-admission-controller"` |  |
| admissionController.image.tag | string | `"0.12.0"` |  |
| admissionController.podSecurityContext.runAsNonRoot | bool | `true` |  |
| admissionController.podSecurityContext.runAsUser | int | `65534` |  |
| admissionController.replicaCount | int | `1` |  |
| admissionController.resources.limits.cpu | string | `"200m"` |  |
| admissionController.resources.limits.memory | string | `"500Mi"` |  |
| admissionController.resources.requests.cpu | string | `"50m"` |  |
| admissionController.resources.requests.memory | string | `"200Mi"` |  |
| nameOverride | string | `""` |  |
| rbac.create | bool | `true` |  |
| recommender.enabled | bool | `true` |  |
| recommender.extraArgs.pod-recommendation-min-cpu-millicores | int | `15` |  |
| recommender.extraArgs.pod-recommendation-min-memory-mb | int | `100` |  |
| recommender.extraArgs.v | string | `"4"` |  |
| recommender.image.pullPolicy | string | `"Always"` |  |
| recommender.image.repository | string | `"k8s.gcr.io/autoscaling/vpa-recommender"` |  |
| recommender.image.tag | string | `"0.12.0"` |  |
| recommender.podSecurityContext.runAsNonRoot | bool | `true` |  |
| recommender.podSecurityContext.runAsUser | int | `65534` |  |
| recommender.replicaCount | int | `1` |  |
| recommender.resources.limits.cpu | string | `"200m"` |  |
| recommender.resources.limits.memory | string | `"1000Mi"` |  |
| recommender.resources.requests.cpu | string | `"50m"` |  |
| recommender.resources.requests.memory | string | `"500Mi"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.automountServiceAccountToken | bool | `true` |  |
| serviceAccount.create | bool | `true` |  |
| serviceAccount.name | string | `""` |  |
| updater.enabled | bool | `true` |  |
| updater.image.pullPolicy | string | `"Always"` |  |
| updater.image.repository | string | `"k8s.gcr.io/autoscaling/vpa-updater"` |  |
| updater.image.tag | string | `"0.12.0"` |  |
| updater.podSecurityContext.runAsNonRoot | bool | `true` |  |
| updater.podSecurityContext.runAsUser | int | `65534` |  |
| updater.replicaCount | int | `1` |  |
| updater.resources.limits.cpu | string | `"200m"` |  |
| updater.resources.limits.memory | string | `"1000Mi"` |  |
| updater.resources.requests.cpu | string | `"50m"` |  |
| updater.resources.requests.memory | string | `"500Mi"` |  |