# helm-secrets-store-csi-driver

Helm chart to install secrets-store-csi-driver

Reference Helm Chart [secrets-store-csi-driver-v0.3.0](https://github.com/kubernetes-sigs/secrets-store-csi-driver/tree/v0.3.0)


## Configuration

Parameter | Description | Default | Required
--- | --- | --- | ---
`aws-provider-installer` | aws provider installer | `false` | no