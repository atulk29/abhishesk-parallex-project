# app

![Version: 1.0.12](https://img.shields.io/badge/Version-1.0.12-informational?style=flat-square)  ![AppVersion: 1.0.0](https://img.shields.io/badge/AppVersion-1.0.0-informational?style=flat-square)

## Description

A Helm chart for deploying microservices

## Maintainers

| Name | Email | Url |
| ---- | ------ | --- |
| Siddharth | <abhibvp003@gmail.com> |  |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| autoscaling.enabled | bool | `false` |  |
| autoscaling.hpa.behavior.scaleDown.policies[0].periodSeconds | int | `30` |  |
| autoscaling.hpa.behavior.scaleDown.policies[0].type | string | `"Pods"` |  |
| autoscaling.hpa.behavior.scaleDown.policies[0].value | int | `1` |  |
| autoscaling.hpa.behavior.scaleDown.stabilizationWindowSeconds | int | `300` |  |
| autoscaling.hpa.enabled | bool | `true` |  |
| autoscaling.hpa.maxReplicas | int | `10` |  |
| autoscaling.hpa.metrics[0].resource.name | string | `"cpu"` |  |
| autoscaling.hpa.metrics[0].resource.target.averageUtilization | int | `80` |  |
| autoscaling.hpa.metrics[0].resource.target.type | string | `"Utilization"` |  |
| autoscaling.hpa.metrics[0].type | string | `"Resource"` |  |
| autoscaling.hpa.minReplicas | int | `1` |  |
| autoscaling.vpa.enabled | bool | `true` |  |
| autoscaling.vpa.resourcePolicy.maxAllowed.cpu | string | `"100m"` |  |
| autoscaling.vpa.resourcePolicy.maxAllowed.memory | string | `"2048Mi"` |  |
| autoscaling.vpa.resourcePolicy.minAllowed.cpu | string | `"50m"` |  |
| autoscaling.vpa.resourcePolicy.minAllowed.memory | string | `"64Mi"` |  |
| autoscaling.vpa.updatePolicy.updateMode | string | `"Auto"` |  |
| config | object | `{}` |  |
| deployment.affinity | object | `{}` |  |
| deployment.annotations | object | `{}` |  |
| deployment.component | string | `"api"` |  |
| deployment.containerPort.http | int | `8080` |  |
| deployment.envFrom | list | `[]` |  |
| deployment.extraEnvs | list | `[]` |  |
| deployment.image.pullPolicy | string | `"IfNotPresent"` |  |
| deployment.image.registry | string | `""` |  |
| deployment.image.repository | string | `"nginx"` |  |
| deployment.image.tag | string | `"latest"` |  |
| deployment.imagePullSecrets | list | `[]` |  |
| deployment.livenessProbe | object | `{}` |  |
| deployment.nodeSelector | object | `{}` |  |
| deployment.podAnnotations | object | `{}` |  |
| deployment.podSecurityContext | object | `{}` |  |
| deployment.readinessProbe | object | `{}` |  |
| deployment.resources.limits.cpu | string | `"1000m"` |  |
| deployment.resources.limits.memory | string | `"512Mi"` |  |
| deployment.resources.requests.cpu | string | `"100m"` |  |
| deployment.resources.requests.memory | string | `"100Mi"` |  |
| deployment.securityContext.privileged | bool | `false` |  |
| deployment.startupProbe | object | `{}` |  |
| deployment.tolerations | list | `[]` |  |
| deployment.volumeMounts | list | `[]` |  |
| deployment.volumes | list | `[]` |  |
| environment | string | `"dev"` |  |
| fullnameOverride | string | `""` |  |
| istio.authorizationPolicy.enabled | bool | `true` |  |
| istio.destinationRule.enabled | bool | `false` |  |
| istio.enabled | bool | `false` |  |
| istio.gateway.enabled | bool | `true` |  |
| istio.gateway.ingressHost | string | `"*"` |  |
| istio.gateway.portName | string | `"http"` |  |
| istio.gateway.portNumber | int | `80` |  |
| istio.gateway.protocol | string | `"HTTP"` |  |
| istio.virtualService.enabled | bool | `true` |  |
| istio.virtualService.gateway | string | `"mesh"` |  |
| istio.virtualService.host | string | `"*"` |  |
| istio.virtualService.timeout | string | `"1m"` |  |
| istio.virtualService.uriPrefix[0] | string | `"/"` |  |
| istio.virtualService.uriPrefix[1] | string | `"/home"` |  |
| namespace | string | `"test"` |  |
| project | string | `"project-name"` |  |
| secretProviderClassAws.enabled | bool | `false` |  |
| secretProviderClassAws.parameters.objects[0].jmesPath[0].objectAlias | string | `"SecretUsername"` |  |
| secretProviderClassAws.parameters.objects[0].jmesPath[0].path | string | `"username"` |  |
| secretProviderClassAws.parameters.objects[0].jmesPath[1].objectAlias | string | `"SecretPassword"` |  |
| secretProviderClassAws.parameters.objects[0].jmesPath[1].path | string | `"password"` |  |
| secretProviderClassAws.parameters.objects[0].objectName | string | `"msdev-credentials"` |  |
| secretProviderClassAws.parameters.objects[0].objectType | string | `"secretsmanager"` |  |
| secretProviderClassAws.provider | string | `"aws"` |  |
| secretProviderClassAws.secretObjects[0].data[0].key | string | `"username"` |  |
| secretProviderClassAws.secretObjects[0].data[0].objectName | string | `"SecretUsername"` |  |
| secretProviderClassAws.secretObjects[0].data[1].key | string | `"password"` |  |
| secretProviderClassAws.secretObjects[0].data[1].objectName | string | `"SecretPassword"` |  |
| secretProviderClassAws.secretObjects[0].secretName | string | `"msdev-credentials"` |  |
| secretProviderClassAws.secretObjects[0].type | string | `"Opaque"` |  |
| secretProviderClassAzure.enabled | bool | `false` |  |
| secretProviderClassAzure.parameters.keyvaultName | string | `"kvault-devparallaxiq"` |  |
| secretProviderClassAzure.parameters.objects[0].objectName | string | `"postgres-password"` |  |
| secretProviderClassAzure.parameters.objects[0].objectType | string | `"secret"` |  |
| secretProviderClassAzure.parameters.objects[0].objectVersion | string | `"955b9f9b518f418790a803ea2056889d"` |  |
| secretProviderClassAzure.parameters.objects[1].objectName | string | `"cmk-parallaxiqdev"` |  |
| secretProviderClassAzure.parameters.objects[1].objectType | string | `"key"` |  |
| secretProviderClassAzure.parameters.objects[1].objectVersion | string | `"152b50041d074518a4047e58fa3a05d6"` |  |
| secretProviderClassAzure.parameters.secretObjects[0].data[0].key | string | `"postgres-password"` |  |
| secretProviderClassAzure.parameters.secretObjects[0].data[0].objectName | string | `"postgres-password"` |  |
| secretProviderClassAzure.parameters.secretObjects[0].secretName | string | `"postgres-password"` |  |
| secretProviderClassAzure.parameters.secretObjects[0].type | string | `"Opaque"` |  |
| secretProviderClassAzure.parameters.tenantId | string | `"3d4d17ea-1ae4-4705-947e-51369c5a5f79"` |  |
| secretProviderClassAzure.parameters.userAssignedIdentityID | string | `"42df19b3-0331-448e-8186-c01b95705a40"` |  |
| secretProviderClassAzure.provider | string | `"azure"` |  |
| service.annotations | object | `{}` |  |
| service.ports[0].name | string | `"http"` |  |
| service.ports[0].port | int | `8080` |  |
| service.ports[0].targetPort | int | `8080` |  |
| service.type | string | `"ClusterIP"` |  |
| serviceAccount.annotations | object | `{}` |  |
| serviceAccount.name | string | `"test"` |  |
| serviceMonitor.additionalLabels | object | `{}` |  |
| serviceMonitor.enabled | bool | `false` |  |
| serviceMonitor.path | string | `"/actuator/prometheus"` |  |
| serviceMonitor.port | string | `"http"` |  |